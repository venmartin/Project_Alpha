iconsimple: logotypes
=====================

Designer: pixan (https://www.iconfinder.com/iconsimple)
License: Creative Commons (Attribution 2.5 Generic) (http://creativecommons.org/licenses/by/2.5/)
